<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Portfolio</title>
    <link rel="stylesheet" href="css1.css">
</head>
<body>
    <a name="home">

    <div class="logo">
        <nav class="nav">
            <h1>PORTFOLIO.</h1>
            <ul>
                <li><a href="#home">HOME</a></li>
                <li><a href="#skill">SKILL</a></li>
                <li><a href="#contact">CONTACT</a></li>
                <li><a href="about.php">DEVELOPER</a></li>
                
            </ul>
        </nav>
        <div class="detail">
            <h1>I'm <span>Vaibhav</span></h1>
            <p>This is my portfolio. First you can look at to my portfolio and <br> as per my portfolio records you can Hire me 
            </p>
            <a href="#hire">HIRE ME</a>               
        </div>
        <div id="p">
            <img src="p.png" alt="p">
        </div>
        <BR><BR><BR><BR><BR><BR><BR><BR><BR>
        <br><BR><BR><BR><a name="skill"></a><BR><BR><BR><BR><BR>
            
            <div id="skill1">
            
            <img src="s01.jpg" alt="skill-full" class="i">
            <img src="s02.jpg" alt="skill-python">
            <img src="s03.jpg" alt="skill-java">
            <br><br><br><br>
            <img src="s04.jpg" alt="skill-c++" class="i">
            <img src="s05.jpg" alt="skill-sql">
            <img src="s06.jpg" alt="skill-Ai">
        </div>
<BR><BR><BR><BR><BR><BR>
   <a name="hire">
   <section class="contact" id="contact">
     <h2 class="heading">Contact<span> Us!</span></h2>
        <form>
            <div class="input-box">
                <input type="text" placeholder="Your Full Name">
                <input type="email" placeholder="Email Address">
            </div>
            <div class="input-box">
                <input type="number" placeholder="Mobile Number">
                <input type="text " placeholder="Email Subject">
            </div>
            <textarea name="" id="" cols="30" rows="10" placeholder="Your Message"></textarea>
          <a href="#home">
            <input type="submit" value="submit" name="submit" class="bton" onclick="o()"></a>
        </form>
    </section>
<br><br><br><br>
<script>
function o(){
    alert("SUBMITTED");
}  
</script>
</body>
</html>